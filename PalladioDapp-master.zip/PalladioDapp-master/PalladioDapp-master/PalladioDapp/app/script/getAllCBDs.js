function onGetFullState(err, res, addresse, currentTime) {
  var cbdObject = {};
  cbdObject['contractAddress'] = addresse;
  cbdObject['state'] = res[0].toString();
  cbdObject['licensedArchitect'] = res[1].toString();
  cbdObject['licensedArchitectString'] = res[2].toString();
  cbdObject['recipient'] = res[3].toString();
  cbdObject['recipientString'] = res[4].toString();
  cbdObject['balance'] = res[5].toString();
  cbdObject['commitThreshold'] = res[6].toString();
  cbdObject['amountDeposited'] = res[7].toString();

  cbdObject['amountReleased'] = res[9].toString();
  cbdObject['defaultAction'] = res[10].toString();
  cbdObject['defaultTimeoutLength'] = res[11].toString();
  cbdObject['defaultTriggerTime'] = res[12].toString();
  cbdObject['defaultTriggerTimePassed'] = (currentTime >= Number(res[12]));
  CBDs.push(cbdObject);
  buildCBDRow();
}

function buildCBDRow(){
  if(CBDs.length !== 1) $("tbody").append($(".mainTableRow").first().clone());
  // console.log(CBD_STATES[CBDs[CBDCount].state]);
  switch(CBD_STATES[CBDs[CBDs.length-1].state]){
    case("Open"):
      $(`.state:eq(${CBDs.length-1})`).parent().css("background-color", "aquamarine");
      break;
    case("Committed"):
      $(`.state:eq(${CBDs.length-1})`).parent().css("background-color", "cyan");
      break;
    case("Expended"):
      $(`.state:eq(${CBDs.length-1})`).parent().css("background-color", "grey");
      break;
  }
  $(`.state:eq(${CBDs.length-1})`).text(CBD_STATES[CBDs[CBDs.length-1].state]);
  $(`.contractAddress:eq(${CBDs.length-1})`).text(CBDs[CBDs.length-1].contractAddress);
  $(`.contractAddress:eq(${CBDs.length-1})`).attr("href", `../layout/interact.html?contractAddress=${CBDs[CBDs.length-1].contractAddress}`);
  $(`.licensedArchitectAddress:eq(${CBDs.length-1})`).html(`\n <a href='${window.etherscanURL}${CBDs[CBDs.length-1].licensedArchitect}'>${CBDs[CBDs.length-1].licensedArchitect}</a>`);
  // $(`.licensedArchitectAddress:eq(${CBDs.length-1})`).text(CBDs[CBDs.length-1].licensedArchitect);
  if(CBDs[CBDs.length-1].recipient !== "0x0000000000000000000000000000000000000000"){
    // $(`.recipientAddress:eq(${CBDs.length-1})`).text("Recipient: \n" + );
    $(`.recipientAddress:eq(${CBDs.length-1})`).html(`Recipient \n <a href='${window.etherscanURL}${CBDs[CBDs.length-1].recipient}'>${CBDs[CBDs.length-1].recipient}</a>`);
  }else{
    $(`.recipientAddress:eq(${CBDs.length-1})`).html(`No Recipient! <a href='../layout/interact.html?contractAddress=${CBDs[CBDs.length-1].contractAddress}'> Commit ether to become the recipient.</a>`);
  }
  $(`.balance:eq(${CBDs.length-1})`).text(web3.fromWei(CBDs[CBDs.length-1].balance, 'ETHER'));
  $(`.commitThreshold:eq(${CBDs.length-1})`).text(web3.fromWei(CBDs[CBDs.length-1].commitThreshold, 'ETHER'));
  $(`.fundsDeposited:eq(${CBDs.length-1})`).text(web3.fromWei(CBDs[CBDs.length-1].amountDeposited, 'ETHER'));
  $(`.fundsReleased:eq(${CBDs.length-1})`).text(web3.fromWei(CBDs[CBDs.length-1].amountReleased, 'ETHER'));
  $(`.defaultAction:eq(${CBDs.length-1})`).text(CBDs[CBDs.length-1].defaultAction);
  $(`.defaultTimeoutLength:eq(${CBDs.length-1})`).text(CBDs[CBDs.length-1].defaultTimeoutLength/60/60 + " hours");
  if(CBDs[CBDs.length-1].defaultTriggerTime != 0){
    if(CBDs[CBDs.length-1].defaultTriggerTimePassed){
      $(`.defaultTriggerTime:eq(${CBDs.length-1})`).text(new Date(CBDs[CBDs.length-1].defaultTriggerTime * 1000).toLocaleString());
      $(`.defaultTriggerTime:eq(${CBDs.length-1})`).css("color","red");
    }
    else{
      $(`.defaultTriggerTime:eq(${CBDs.length-1})`).text(secondsToDhms(Number(CBDs[CBDs.length-1].defaultTriggerTime - currentTime)));
      $(`.defaultTriggerTime:eq(${CBDs.length-1})`).css("color","green");
    }
  }
  else{
    $(`.defaultTriggerTime:eq(${CBDs.length-1})`).text(0);
  }
  $(`.licensedArchitectString:eq(${CBDs.length-1})`).text(CBDs[CBDs.length-1].licensedArchitectString);
  $(`.recipientString:eq(${CBDs.length-1})`).text(CBDs[CBDs.length-1].recipientString);
}

window.addEventListener('load', function() {
  if (typeof web3 !== 'undefined') {
      window.web3 = new Web3(web3.currentProvider);
  }
  else {
      alert("metamask/mist not detected. This site probably won't work for you. Download the metamask addon and try again!");
  }
  web3.version.getNetwork((err, netID) => {
    if (netID == 1) {
        console.log("You are on the Ethereum main net!");
        window.etherscanURL = "https://etherscan.io/address/"
        window.CBDFactoryCreationBlock = 4207091;
    }
    else if (netID == 3) {
        console.log("You are on the Ropsten net!");
        //CBD_FACTORY_ADDRESS = '0x92bfC1D80dD7F5BCc7851F6584c7B2e3b0Fb8D4d'//'0x';
        window.etherscanURL = "https://ropsten.etherscan.io/address/";
        window.CBDFactoryCreationBlock = 0;
    }
    else{
      alert("You aren't on the Ethereum main or Ropsten net! Try changing your metamask options to connect to the main network.");
    }
    window.CBDFactory = {
        "address": CBD_FACTORY_ADDRESS,
        "ABI": CBD_FACTORY_ABI
    };
    CBDFactory.contract = web3.eth.contract(CBDFactory.ABI);
    CBDFactory.contractInstance = CBDFactory.contract.at(CBDFactory.address);

    //get all newCBD events
    window.CBDs = [];
    window.event = CBDFactory.contractInstance.NewCBD({}, {"fromBlock": CBDFactoryCreationBlock});//NewCBD is an event, not a method; it returns an event object.
    // window.recoverEvent = CBDFactory.contractInstance.FundsRecovered({}, {"fromBlock": 1558897});

    currentCBD = {
        "address": "",
        "ABI": CBD_ABI
    };

    currentCBD.contract = web3.eth.contract(currentCBD.ABI);

    web3.eth.getBlock("latest",function(err,res){
      if (err) {
          console.log("Error calling CBD method: " + err.message);
      }
      else{
        currentTime = res.timestamp;
        CBDFactory.contractInstance.getContractCount(function(err,res){
          if (err) {
              console.log("Error calling CBD method: " + err.message);
          }
          else {
            var contractArray = [];
            for(var conCounter = 0; conCounter < Number(res); conCounter++){
              CBDFactory.contractInstance.contracts(conCounter, function(err,res){
                if (err) {
                    console.log("Error calling CBD method: " + err.message);
                }
                else{
                  var currentAddress = res;
                  (function(currentAddress){
                    web3.eth.getCode(currentAddress, function(err, res){
                      if(err){
                        console.log("Error calling CBD method: " + err.message);
                      }
                      else if(res !== "0x"){
                        currentCBD.contractInstance = currentCBD.contract.at(currentAddress);
                        currentCBD.contractInstance.getFullState(function(err,res){
                          if(err){
                            console.log("Error calling CBD method: " + err.message);
                          }
                          else{
                            onGetFullState(err, res, currentAddress, currentTime);
                          }
                        });
                      }
                    });
                  })(currentAddress);
                }
              });
            }
          }
        });
      }
    });
  });
});
