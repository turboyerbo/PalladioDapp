function handleNewCBDResult(err, res) {
    if (err) alert(err.message);
    else {
        $("outputDiv").html("CBD Creation transaction submitted. Address (upon transaction confirmation): " + res);
    }
}
function callNewCBD(valueInEth, licensedArchitect, commitThresholdInEth, hasDefaultAction, defaultTimeoutLengthInHours, licensedArchitectString) {
    var valueInWei = web3.toWei(valueInEth, 'ether');
    var commitThresholdInWei = web3.toWei(commitThresholdInEth, 'ether');
    var defaultTimeoutLengthInSeconds = defaultTimeoutLengthInHours*60*60;

    CBDFactory.contractInstance.newBurnableOpenPayment(licensedArchitect, commitThresholdInWei, hasDefaultAction, defaultTimeoutLengthInSeconds, licensedArchitectString, {'from':web3.eth.accounts[0],'value': valueInWei}, handleNewCBDResult);
}

function useCBDFormInput() {
    var valueInEth = $("#NewCBDForm #paymentAmountInput").val();
    if (valueInEth == '') {
        alert("Must specify payment amount!");
        return;
    }
    valueInEth = Number(valueInEth);

    var licensedArchitect = $("#NewCBDForm #licensedArchitectInput").val();
    if (licensedArchitect == '') {
        alert("Must specify licensedArchitect!");
        return;
    }

    var commitThresholdInEth = $("#NewCBDForm #commitThresholdInput").val();
    if (commitThresholdInEth == '') {
        alert("Must specify commit threshold!");
        return;

    var commitRecordBook = $("#NewCBDForm #category").val();
    if (commitRecordBook == '') {
            alert("Must specify commit Record Book!");
            return;

    }
    commitThresholdInEth = Number(commitThresholdInEth);

    var hasDefaultAction = ($('input[name=hasDefaultActionInput]:checked', '#NewCBDForm').val() === "true");

    if (hasDefaultAction) {
        var defaultTimeoutLengthInHours = $("#NewCBDForm #defaultTimeoutLengthInHoursInput").val();
        if (defaultTimeoutLengthInHours == '') {
            alert("Must specify a default timeout length! (Or set default action to \"None\")");
            return;
        }
        defaultTimeoutLengthInHours = Number(defaultTimeoutLengthInHours);
    }
    else var defaultTimeoutLengthInHours = 0;

    var licensedArchitectString = $("#NewCBDForm #licensedArchitectStringInput").val();
    if (licensedArchitectString == '') {
        if (!confirm("Initial licensedArchitectString is empty! Are you sure you want to open a CBD without a licensedArchitectString?")) {
            return;
        }
    }
    callNewCBD(valueInEth, licensedArchitect, commitThresholdInEth, hasDefaultAction, defaultTimeoutLengthInHours, licensedArchitectString);
}

function populatelicensedArchitectInputFromMetamask() {
    if ($("#licensedArchitectInput").val() == "") {
        $("#licensedArchitectInput").val(web3.eth.accounts[0])
    }
}

window.addEventListener('load', function() {
    if (typeof web3 !== 'undefined') {
        window.web3 = new Web3(web3.currentProvider);
    }
    else {
        alert("metamask/mist not detected. This site probably won't work for you. Download the metamask addon and try again!");
    }
    web3.version.getNetwork((err, netID) => {
        if (netID == 1) {
            console.log("You are on the Ethereum main net!");
        }
        else if (netID == 3) {
            console.log("You are on the Ropsten net!");
            // CBD_FACTORY_ADDRESS = '0x92bfC1D80dD7F5BCc7851F6584c7B2e3b0Fb8D4d'//'0x..';
        }
        else{
          alert("You aren't on the Ethereum main or Ropsten net! Try changing your metamask options to connect to the main network.");
        }
        window.CBDFactory = {
            "address": CBD_FACTORY_ADDRESS,
            "ABI": CBD_FACTORY_ABI
        };
        CBDFactory.contract = web3.eth.contract(CBDFactory.ABI);
        CBDFactory.contractInstance = CBDFactory.contract.at(CBDFactory.address);
    });
});

}
