window.addEventListener('load', function() {
  if (typeof web3 !== 'undefined') {
      window.web3 = new Web3(web3.currentProvider);
  }
  else {
      console.log("metamask/mist not detected. This site probably won't work for you. Download the metamask addon and try again!");
  }
  //get GET-Parameter from URL to decide on contract
  window.address = getUrlParameter('contractAddress');

  web3.version.getNetwork((err, netID) => {
    if (netID == 1) {
      console.log("You are on the Ethereum main net!");
      if(typeof window.address == "undefined") window.address = "0x..";
      window.etherscanURL = "https://etherscan.io/address/"
    }
    else if (netID == 3) {
      console.log("You are on the Ropsten net!");
      // window.address = "0x...";
      if(typeof window.address == "undefined") window.address = "0x92bfC1D80dD7F5BCc7851F6584c7B2e3b0Fb8D4d";
      window.etherscanURL = "https://ropsten.etherscan.io/address/";
      $("h1").text($("h1").text() + " (ROPSTEN)");
    }
    else{
      console.log("You aren't on the Ethereum main or Ropsten net! Try changing your metamask options to connect to the main network.");
    }
    //Initialize the CBD object to interact with the smart contract(CBD)
    window.CBD = {
        "address": window.address,
        "ABI": CBD_ABI,
    };
    CBD.contract = web3.eth.contract(CBD.ABI);
    CBD.contractInstance = CBD.contract.at(CBD.address);
    getEventsAndParticipants('logs','getLogs','address=' + window.address);

    window.checkUserAddressesInterval = setInterval(checkForUserAddresses, 1000);
    window.getFullStateInterval = setInterval(function(){
      web3.eth.getCode(window.address,function(err,res){
        if(res == "0x"){
          console.log("This Contract doesn't exist or was destroyed.")
          document.getElementById('licensedArchitectFundsInputGroup').hidden = true;
          document.getElementById('updatelicensedArchitectStringInputGroup').hidden = true;
          document.getElementById('updateRecipientStringInputGroup').hidden = true;
          document.getElementById('commitInputGroup').hidden = true;
        	document.getElementById('recoverFundsInputGroup').hidden = true;
          document.getElementById('defaultActionInputGroup').hidden = true;
          document.getElementById('delayDefaultActionForm').hidden = true;
          $('.insertAddress').text(CBD.address);
          $('#etherscanLink').attr("href", `${window.etherscanURL}${CBD.address}`);
          $('#CBDInfoOutput').text("Doesn't exist/Destroyed");
          $('#CBDlicensedArchitectOutput').text("None")
          $('#CBDRecipientOutput').text("None")
          $('#CBDlicensedArchitectStringOutput').text("None");
          $('#CBDRecipientStringOutput').text("None");
          $('#CBDBalanceOutput').text("None");
          $('#CBDCommitThresholdOutput').text("None");
          $('#CBDFundsDepositedOutput').text("None");
          $('#CBDFundsReleasedOutput').text("None");
          $('#CBDDefaultActionOutput').text("None");
          $('#CBDDefaultTimeoutLength').text("None");
          $('#CBDTable').css("background-color", "grey");
        }
        else{
          CBD.contractInstance.getFullState(function(err, res){
            if (err) {
              console.log("Error calling CBD method: " + err.message);
              ////workaournd////////////////////////////////////////////////////////
              console.log("This Contract doesn't exist or was destroyed.")
              document.getElementById('licensedArchitectFundsInputGroup').hidden = true;
              document.getElementById('updatelicensedArchitectStringInputGroup').hidden = true;
              document.getElementById('updateRecipientStringInputGroup').hidden = true;
              document.getElementById('commitInputGroup').hidden = true;
              document.getElementById('recoverFundsInputGroup').hidden = true;
              document.getElementById('defaultActionInputGroup').hidden = true;
              document.getElementById('delayDefaultActionForm').hidden = true;

              $('.insertAddress').text(CBD.address);
              $('#etherscanLink').attr("href", `${window.etherscanURL}${CBD.address}`);
              $('#CBDInfoOutput').text("Doesn't exist/Destroyed");
              $('#CBDlicensedArchitectOutput').text("None")
              $('#CBDRecipientOutput').text("None")
              $('#CBDlicensedArchitectStringOutput').text("None");
              $('#CBDRecipientStringOutput').text("None");
              $('#CBDBalanceOutput').text("None");
              $('#CBDCommitThresholdOutput').text("None");
              $('#CBDFundsDepositedOutput').text("None");

              $('#CBDFundsReleasedOutput').text("None");
              $('#CBDDefaultActionOutput').text("None");
              $('#CBDDefaultTimeoutLength').text("None");
              $('#CBDTable').css("background-color", "grey");
              ////workaournd////////////////////////////////////////////////////////
            }
            else{
              CBD['state'] = res[0].toString();
              CBD['licensedArchitect'] = res[1].toString();
              CBD['licensedArchitectString'] = res[2].toString();
              CBD['recipient'] = res[3].toString();
              CBD['recipientString'] = res[4].toString();
              CBD['balance'] = res[5].toString();
              CBD['commitThreshold'] = res[6].toString();
              CBD['amountDeposited'] = res[7].toString();
          
              CBD['amountReleased'] = res[9].toString();
              CBD['defaultAction'] = res[10].toString() === "true";
              CBD['defaultTimeoutLength'] = res[11].toString();
              CBD['defaultTriggerTime'] = res[12].toString();
              insertInstanceStatsInPage();
              if (CBD_STATES[Number(CBD.state)] == 'Open') $('#CBDTable').css("background-color", "rgb(204, 255, 204)");
              if (CBD_STATES[Number(CBD.state)] == "Committed") $('#CBDTable').css("background-color", "cyan");
              if (CBD_STATES[Number(CBD.state)] == "Expended") $('#CBDTable').css("background-color", "grey");
              updateExtraInput();
            }
          });
        }
      })
    }, 3000);
  });
});

function insertInstanceStatsInPage(){
    $('.insertAddress').text(CBD.address);
    $('#etherscanLink').attr("href", `${window.etherscanURL}${CBD.address}`);
    $('#CBDInfoOutput').text(CBD_STATES[CBD.state]);
    $('#CBDlicensedArchitectOutput').text(CBD.licensedArchitect)
    $('#CBDlicensedArchitectStringOutput').text(CBD.licensedArchitectString);
    CBD.recipient == '0x0000000000000000000000000000000000000000' ? $('#CBDRecipientOutput').text("None") : $('#CBDRecipientOutput').text(CBD.recipient);
    $('#CBDRecipientStringOutput').text(CBD.recipientString, 'ether');
    $('#CBDBalanceOutput').text(web3.fromWei(CBD.balance, 'ether') + ' ETH');
    $('#CBDCommitThresholdOutput').text(web3.fromWei(CBD.commitThreshold,'ether') + ' ETH');
    $('#CBDFundsDepositedOutput').text(web3.fromWei(CBD.amountDeposited, 'ether') + ' ETH');

    $('#CBDFundsReleasedOutput').text(web3.fromWei(CBD.amountReleased, 'ether') + ' ETH');
    $('#CBDDefaultActionOutput').text(CBD.defaultAction);
    $('#CBDDefaultTimeoutLength').text(secondsToDhms(CBD.defaultTimeoutLength));
    $('#CBDDefaultActionTriggerTime').text(new Date(CBD.defaultTriggerTime * 1000).toLocaleString());
}


function updateExtraInput() {
	var userHasAddress = (isUserAddressVisible());
  var userIslicensedArchitect = (CBD.licensedArchitect == web3.eth.defaultAccount);
  var userIsRecipient = (CBD.recipient == web3.eth.defaultAccount);
  var isNullRecipient = (CBD.recipient == '0x0000000000000000000000000000000000000000');

  document.getElementById('licensedArchitectFundsInputGroup').hidden = !userIslicensedArchitect;
  document.getElementById('updatelicensedArchitectStringInputGroup').hidden = !userIslicensedArchitect;
  document.getElementById('updateRecipientStringInputGroup').hidden = !userIsRecipient;
  document.getElementById('commitInputGroup').hidden = !isNullRecipient;
	document.getElementById('recoverFundsInputGroup').hidden = !(userIslicensedArchitect && isNullRecipient);
  web3.eth.getBlock("latest",
    function(err,res){
      if (err) {
          console.log("Error calling CBD method: " + err.message);
      }
      else{
        currentTime = res.timestamp;
      }
      if(!CBD.defaultAction){
        document.getElementById('CBDDefaultActionTriggerTime').hidden = true;
        document.getElementById('CBDDefaultTimeoutLengthGroup').hidden = true;
        document.getElementById('defaultActionInputGroup').hidden = true;
        document.getElementById('delayDefaultActionForm').hidden = true;
      }
      if(!(userIsRecipient || userIslicensedArchitect)){
        document.getElementById('defaultActionInputGroup').hidden = true;
        document.getElementById('delayDefaultActionForm').hidden = true;
      }
      else if((CBD.defaultAction && Number(CBD.defaultTriggerTime) < currentTime && CBD_STATES[Number(CBD.state)] === 'Committed' && (userIsRecipient || userIslicensedArchitect))){
        console.log(1)
        document.getElementById('CBDDefaultActionTriggerTime').hidden = false;
        document.getElementById('CBDDefaultTimeoutLengthGroup').hidden = false;
        document.getElementById('defaultActionInputGroup').hidden = false;
        document.getElementById('delayDefaultActionForm').hidden = false;
      }
      else if((CBD.defaultAction && Number(CBD.defaultTriggerTime) > currentTime && CBD_STATES[Number(CBD.state)] === 'Committed' && (userIsRecipient || userIslicensedArchitect))){
        document.getElementById('CBDDefaultActionTriggerTime').hidden = false;
        document.getElementById('CBDDefaultTimeoutLengthGroup').hidden = false;
        document.getElementById('defaultActionInputGroup').hidden = true;
        document.getElementById('delayDefaultActionForm').hidden = true;
        differenceTime = Number(CBD.defaultTriggerTime) - res.timestamp;
        if(0 < differenceTime && differenceTime <= 86400){
          $('#CBDDefaultActionTriggerTime').text("Remaining Time: " + secondsToDhms(differenceTime));
        }
        else{
          $('#CBDDefaultActionTriggerTime').text(new Date(CBD.defaultTriggerTime * 1000).toLocaleString());
          $('#CBDDefaultActionTriggerTime').css("color", "red");
        }
      }
      else if(CBD.defaultAction && Number(CBD.defaultTriggerTime) < currentTime && CBD_STATES[Number(CBD.state)] === 'Committed'){
        document.getElementById('CBDDefaultActionTriggerTime').hidden = false;
        document.getElementById('CBDDefaultTimeoutLengthGroup').hidden = false;
      }
      else if(CBD.defaultAction && CBD_STATES[Number(CBD.state)] === 'Committed'){
        document.getElementById('CBDDefaultActionTriggerTime').hidden = false;
        document.getElementById('CBDDefaultTimeoutLengthGroup').hidden = false;
      }
      else if(CBD.defaultAction){
        document.getElementById('CBDDefaultActionTriggerTime').hidden = true;
        document.getElementById('CBDDefaultTimeoutLengthGroup').hidden = false;
      }
  });
}

function isUserAddressVisible() {
	return (typeof(web3.eth.accounts) != 'undefined' && web3.eth.accounts.length > 0);
}
function checkForUserAddresses() {
    if (isUserAddressVisible()) {
        clearInterval(checkUserAddressesInterval);
        onUserAddressesVisible();
    }
    else {
        onUserAddressesNotVisible();
    }
}
function onUserAddressesNotVisible() {
    document.getElementById('userAddress').innerHTML = "Can't find user addresses. If using metamask, are you sure it's unlocked and initialized?<br>";
}
function onUserAddressesVisible() {
    web3.eth.defaultAccount = web3.eth.accounts[0];
    document.getElementById('userAddress').innerHTML = "User address:<br>" + web3.eth.defaultAccount;
}

function recipientStringEditMode(flag) {
	if (flag) {
		$('#recipientStringUpdateStartButton').hide();
		$('#recipientStringUpdateTextarea').show();
		$('#recipientStringUpdateCommitButton').show();
		$('#recipientStringUpdateCancelButton').show();
		$('#CBDRecipientStringOutput').hide();
	}
	else {
		$('#recipientStringUpdateStartButton').show();
		$('#recipientStringUpdateTextarea').hide();
		$('#recipientStringUpdateCommitButton').hide();
		$('#recipientStringUpdateCancelButton').hide();
		$('#CBDRecipientStringOutput').show();
	}
}
function startRecipientStringUpdate() {
	recipientStringEditMode(true);

	$('#recipientStringUpdateTextarea').val(CBD.recipientString);
}
function cancelRecipientStringUpdate() {
	recipientStringEditMode(false);
}
function commitRecipientStringUpdate() {
	callUpdateRecipientString($('#recipientStringUpdateTextarea').val());
	recipientStringEditMode(false);
}

function licensedArchitectStringEditMode(flag) {
	if (flag) {
		$('#licensedArchitectStringUpdateStartButton').hide();
		$('#licensedArchitectStringUpdateTextarea').show();
		$('#licensedArchitectStringUpdateCommitButton').show();
		$('#licensedArchitectStringUpdateCancelButton').show();
		$('#CBDlicensedArchitectStringOutput').hide();
	}
	else {
		$('#licensedArchitectStringUpdateStartButton').show();
		$('#licensedArchitectStringUpdateTextarea').hide();
		$('#licensedArchitectStringUpdateCommitButton').hide();
		$('#licensedArchitectStringUpdateCancelButton').hide();
		$('#CBDlicensedArchitectStringOutput').show();
	}
}
function startlicensedArchitectStringUpdate() {
	licensedArchitectStringEditMode(true);

	$('#licensedArchitectStringUpdateTextarea').val(CBD.licensedArchitectString);
}
function cancellicensedArchitectStringUpdate() {
	licensedArchitectStringEditMode(false);
}
function commitlicensedArchitectStringUpdate() {
	callUpdatelicensedArchitectString($('#licensedArchitectStringUpdateTextarea').val());
	licensedArchitectStringEditMode(false);
}


//smart contract caller and handler functions
function handleCommitResult(err, res) {
    if (err) console.log(err.message);
}
function callCommit() {
    CBD.contractInstance.commit({'value':CBD.commitThreshold}, handleCommitResult);
}
function handleRecoverFundsResult(err, res) {
	if (err) console.log(err.message);
}
function callRecoverFunds() {
	CBD.contractInstance.recoverFunds(handleRecoverFundsResult);
}
function handleReleaseResult(err, res) {
    if (err) console.log(err.message);
}
function callRelease(amountInEth) {
    CBD.contractInstance.release(web3.toWei(amountInEth,'ether'), handleReleaseResult);
}
function releaseFromForm() {
    var form = document.getElementById('licensedArchitectFundsInputGroup');
    var amount = Number(form.elements['amount'].value);

    callRelease(amount);
}
function handleBurnResult(err, res) {
    if (err) console.log(err.message);
}
function callBurn(amountInEth) {
    CBD.contractInstance.burn(web3.toWei(amountInEth,'ether'), handleBurnResult);
}
function burnFromForm() {
    var form = document.getElementById('licensedArchitectFundsInputGroup');
    var amount = Number(form.elements['amount'].value);

    callBurn(amount);
}
function handleAddFundsResult(err, res) {
	if (err) console.log(err.message);
}
function callAddFunds(includedEth) {
	CBD.contractInstance.addFunds({'value':web3.toWei(includedEth,'ether')}, handleAddFundsResult)
}
function addFundsFromForm() {
	var form = document.getElementById('licensedArchitectFundsInputGroup');
	var amount = Number(form.elements['amount'].value);
	callAddFunds(amount);
}
function callDefaultAction(){
  CBD.contractInstance.callDefaultRelease(logCallResult);
}
function delayDefaultRelease(){
  // var delayDefaultActionInHours = Number($('input[type=text]', '#delayDefaultActionForm').val());
  CBD.contractInstance.delayDefaultRelease(logCallResult);
}
function handleUpdateRecipientStringResult(err, res) {
    if (err) console.log(err.message);
}
function callUpdateRecipientString(newString) {
    CBD.contractInstance.setRecipientString(newString, handleUpdateRecipientStringResult);
}
function handleUpdatelicensedArchitectStringResult(err, res) {
    if (err) console.log(err.message);
}
function callUpdatelicensedArchitectString(newString) {
    CBD.contractInstance.setlicensedArchitectString(newString, handleUpdatelicensedArchitectStringResult);
}
function callCancel() {
    CBD.contractInstance.recoverFunds(logCallResult);
}
function callGetFullState() {
    CBD.contractInstance.licensedArchitect(logCallResult);
}


//////////////////////////////////Events Part of the interact page////////////////////////////////////////////////
function buildEventsPage(logArray, licensedArchitect, recipient){
  var who;
  var logArrayCounter = 0;
  var eventArray = [];
  logArray.forEach(function(log){
    var eventObject = {};
    (function(log){
      web3.eth.getTransaction(log.transactionHash, function(err,res){
        if(err){
          console.log("Error calling CBD method: " + err.message);
        }
        else{
          var topic = log.topics[0];
          var event = decodeTopic(topic, CBD_ABI);
          if(licensedArchitect === recipient && false){
            who = "contract";
          }
          else if(res.from === licensedArchitect){
            who = "licensedArchitect";
          }
          else if(res.from === recipient){
            who = "recipient";
          }
          eventObject.who = who;
          eventObject.event = event;
          eventObject.timeStamp = log.timeStamp;
          eventObject.arguments = returnEventArguments(log.data, event.inputs)
          eventArray.push(eventObject);

          logArrayCounter += 1;
          if(logArrayCounter === logArray.length){
            eventArray = sortOnTimestamp(eventArray);
            insertAllInChat(eventArray);
          }
        }
      });
    })(log);
  });
}

function returnEventArguments(rawArguments, eventInfo){
  var rawArgumentArray = rawArguments.substring(2).match(/.{1,64}/g);
  var argumentString;
  for(var counter = 0; counter < rawArgumentArray.length; counter++){
    var argumentEncoded = rawArgumentArray[counter];
    switch(eventInfo[counter]){
      case "address":
        argumentString += "0x" + argumentEncoded;
        break;
      case "uint256":
        argumentString += parseInt(argumentEncoded, 16);
        break;
      case "string":
        argumentString += web3.toAscii(argumentString);
        break;
      case "bool":
        argumentString += argumentString === "1";
        break;
      default:
    }
  }
}

function insertAllInChat(eventArray){
  eventArray.forEach(function(eventObject){
    insertChat(eventObject.who, eventObject.event.name, new Date(parseInt(eventObject.timeStamp, 16) * 1000).toLocaleString());
  });
}

function getEventsAndParticipants(moduleParam, actionParam, additionalKeyValue){
  CBD.contractInstance.getFullState(function(err, res){
    if (err) {
      console.log("Error calling CBD method: " + err.message);
    }
    else{
      var licensedArchitect = res[1].toString();
      var recipient = res[3].toString();
      callEtherscanApi(moduleParam, actionParam, additionalKeyValue, function(resultJSON){
        buildEventsPage(resultJSON.result, licensedArchitect, recipient)
      });
    }
  });
}

function callEtherscanApi(moduleParam, actionParam, additionalKeyValue, callback){
  var request = new XMLHttpRequest();
  request.onreadystatechange = function(){
    if(this.readyState == 4){
      if(this.status == 200){
        var resultParsed = JSON.parse(this.responseText);
        console.log(resultParsed);
        callback(resultParsed);
      }
    }
  }
  request.open('GET', `https://ropsten.etherscan.io/api?module=${moduleParam}&action=${actionParam}&${additionalKeyValue}&fromBlock=0&toBlock=latest`, true);
  request.send();
}

function decodeTopic(topic, abi){
  for (var methodCounter = 0; methodCounter < abi.length; methodCounter++) {
    var item = abi[methodCounter];
    if (item.type != "event") continue;
    var signature = item.name + "(" + item.inputs.map(function(input) {return input.type;}).join(",") + ")";
    var hash = web3.sha3(signature);
    if (hash == topic) {
      return item;
    }
  }
}

function insertChat(who, text, date){
  var control = "";
  if (who === "licensedArchitect"){
    control =
    '<li class="list-group-item list-group-item-success" style="width:100%">' +
      '<div class="row">' +
        '<div class="col-md-4">' +
          '<span>' + text + '</span>' +
          '<p><small>' + date + '</small></p>' +
        '</div>' +
        '<div class="col-md-4"></div>' +
        '<div class="col-md-4"></div>' +
      '</div>' +
    '</li>';
  }
  else if(who === "recipient"){
    control =
      '<li class="list-group-item list-group-item-info" style="width:100%;">' +
        '<div class="row">' +
          '<div class="col-md-4"></div>' +
          '<div class="col-md-4"></div>' +
          '<div class="col-md-4">' +
            '<span>' + text + '</span>' +
            '<p><small>' + date + '</small></p>' +
          '</div>' +
        '</div>' +
      '</li>';
  }
  $("ul").append(control);
}


function sortOnTimestamp(eventArray){
  eventArray.sort(function(current, next){
    if(current.timeStamp < next.timeStamp) return -1;
    if(current.timeStamp > next.timeStamp) return 1;
    return 0;
  });
  return eventArray;
}
