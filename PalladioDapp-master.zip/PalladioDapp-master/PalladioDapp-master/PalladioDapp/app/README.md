# Palladio

Palladio is a client-side interface for creating design contracts and interacting with Collaborative Blockchain Design tools (CBDs). This is a new way to think about architectural design and implementation.

The emphasis with CBDs is placed upon high volume. Rather than one special genious architect coming up with thousands of ideas, they outsource many quick, simple, easy-to-complete tasks to a fleet of verified Associate Architects. The result of this process is a large and varied pool of submissions to choose from, instead of relying on one person to come up with a multitude of solutions in a short time.